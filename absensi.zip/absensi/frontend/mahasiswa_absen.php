<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absensi dan Lokasi</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.8/html5-qrcode.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js"></script>
</head>
<body>
    <div class="container">
        <h2>Absensi Mahasiswa</h2>
        <form id="absensiForm" action="../backend/mahasiswa/proses_absensi.php" method="POST">
            <div id="step-1">
                <h3>Step 1: Isi Data Absensi</h3>
                <div class="form-group">
                    <label for="nama_lengkap">Nama Lengkap:</label>
                    <input type="text" name="nama_lengkap" id="nama_lengkap" required>
                </div>
                <div class="form-group">
                    <label for="identifier">NIM:</label>
                    <input type="text" name="identifier" id="identifier" required>
                </div>
                <div class="form-group">
                    <label for="kehadiran">Kehadiran:</label>
                    <select name="kehadiran" id="kehadiran" required>
                        <option value="Hadir">Hadir</option>
                        <option value="Sakit">Sakit</option>
                        <option value="Izin">Izin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="hari">Hari/Tanggal:</label>
                    <input type="date" name="tanggal" id="tanggal" required>
                </div>
                <div class="form-group">
                    <label for="mata_kuliah">Mata Kuliah:</label>
                    <select name="mata_kuliah" id="mata_kuliah" required>
                        <option value="Bahasa Inggris">Bahasa Inggris</option>
                        <option value="Ilmu Sosial & Budaya Dasar">Ilmu Sosial & Budaya Dasar</option>
                        <option value="Pemrograman Web">Pemrograman Web</option>
                        <option value="Struktur Data">Struktur Data</option>
                        <option value="Matematika Diskrit">Matematika Diskrit</option>
                        <option value="Matematika Diskrit">Matematika Diskrit</option>
                        <option value="Jaringan Komputer 1">Jaringan Komputer</option>
                        <option value="Sistem Basis Data">Sistem Basis Data</option>
                    </select>
                </div>
                <button type="button" id="nextStep">Next</button>
            </div>

            <div id="step-2" style="display: none;">
                <h3>Step 2: Isi Lokasi Anda</h3>
                <div class="form-group">
                    <label for="lokasi">Lokasi Anda:</label>
                    <input type="text" name="lokasi" id="lokasi" readonly required>
                    <button type="button" id="get-location">Dapatkan Lokasi</button>
                    <div id="map" style="height: 300px; margin-top: 10px;"></div>
                </div>

                <h3>Step 3: Scan QR Code</h3>
                <div class="form-group">
                    <label for="qrcode">Scan QR Code:</label>
                    <div id="reader" style="width: 300px; margin-bottom: 10px;"></div>
                    <input type="text" name="qrcode" id="qrcode" readonly required>
                </div>

                <h3>Generate QR Code Anda</h3>
                <div class="form-group">
                    <button type="button" id="generate-qr">Generate dan Download QR Code</button>
                    <canvas id="qrCanvas" style="display: none;"></canvas>
                    <a id="downloadQR" style="display: none;">Download QR Code</a>
                </div>

                <button type="submit">Submit</button>
            </div>
        </form>
    </div>

    <script>
        let map, marker;

        // Navigasi langkah
        document.getElementById('nextStep').addEventListener('click', function () {
            document.getElementById('step-1').style.display = 'none';
            document.getElementById('step-2').style.display = 'block';
        });

        // Ambil lokasi menggunakan Geolocation API atau fallback IP geolocation
        document.getElementById('get-location').addEventListener('click', function () {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function (position) {
                    const latitude = position.coords.latitude;
                    const longitude = position.coords.longitude;

                    document.getElementById('lokasi').value = `${latitude}, ${longitude}`;

                    if (!map) {
                        map = new google.maps.Map(document.getElementById("map"), {
                            center: { lat: latitude, lng: longitude },
                            zoom: 15,
                        });
                    }

                    if (!marker) {
                        marker = new google.maps.Marker({
                            position: { lat: latitude, lng: longitude },
                            map: map,
                            title: "Lokasi Anda",
                        });
                    } else {
                        marker.setPosition({ lat: latitude, lng: longitude });
                        map.setCenter({ lat: latitude, lng: longitude });
                    }
                }, function () {
                    alert('Gagal mendapatkan lokasi. Menggunakan fallback IP.');
                    fetch('https://ipapi.co/json/')
                        .then(response => response.json())
                        .then(data => {
                            const latitude = parseFloat(data.latitude);
                            const longitude = parseFloat(data.longitude);
                            document.getElementById('lokasi').value = `${latitude}, ${longitude}`;

                            if (!map) {
                                map = new google.maps.Map(document.getElementById("map"), {
                                    center: { lat: latitude, lng: longitude },
                                    zoom: 15,
                                });
                            }

                            if (!marker) {
                                marker = new google.maps.Marker({
                                    position: { lat: latitude, lng: longitude },
                                    map: map,
                                    title: "Lokasi Anda",
                                });
                            }
                        });
                });
            } else {
                alert('Browser Anda tidak mendukung Geolocation.');
            }
        });

        // Scan QR Code
        const html5QrcodeScanner = new Html5QrcodeScanner("reader", {
            fps: 10,
            qrbox: 250
        });
        html5QrcodeScanner.render(decodedText => {
            document.getElementById('qrcode').value = decodedText;
            alert(`QR Code berhasil dibaca: ${decodedText}`);
        });

        // Generate dan Download QR Code
        document.getElementById('generate-qr').addEventListener('click', function () {
            const nama = document.getElementById('nama_lengkap').value;
            const nim = document.getElementById('identifier').value;
            const qrData = `Nama: ${nama}\nNIM: ${nim}`;
            const qr = qrcode(0, 'L');
            qr.addData(qrData);
            qr.make();

            const canvas = document.getElementById('qrCanvas');
            const ctx = canvas.getContext('2d');
            canvas.width = 250;
            canvas.height = 250;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            qr.renderTo2dContext(ctx, canvas.width / qr.getModuleCount());

            const downloadLink = document.getElementById('downloadQR');
            downloadLink.href = canvas.toDataURL();
            downloadLink.download = `qrcode_${nama}.png`;
            downloadLink.style.display = 'block';
            downloadLink.click();
        });
    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY"></script>
</body>
</html>
