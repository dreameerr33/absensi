<?php
session_start();
if (isset($_SESSION['user'])) {
    // Redirect based on role
    if ($_SESSION['user']['role'] === 'admin') {
        header("Location: admin_dashboard.php");
    } elseif ($_SESSION['user']['role'] === 'superuser') {
        header("Location: superuser_dashboard.php");
    } elseif ($_SESSION['user']['role'] === 'mahasiswa') {
        header("Location: mahasiswa_absen.php");
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="../backend/auth/login.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>
    </div>
</body>
</html>
