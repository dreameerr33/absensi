<?php
// Include koneksi database
require_once '../backend/config/database.php';

// Query untuk mendapatkan data absensi
$query = "SELECT * FROM absensi";
$result = $conn->query($query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <h2>Dashboard Admin</h2>
        <a href="../backend/auth/logout.php">Logout</a>
        <table border="" cellpadding="10" cellspacing="0"></table>
<table>
    <thead>
        <tr>
            <th>Nama</th>
            <th>NIM</th>
            <th>Mata Kuliah</th>
            <th>Hari/Tanggal</th>
            <th>Kehadiran</th>
            <th>Lokasi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $nama = $row['nama_lengkap'] ?? 'Tidak Ada Nama';
                $identifier = $row['identifier'] ?? 'Tidak Ada NIM';
                $mata_kuliah = $row['mata_kuliah'] ?? 'Tidak Ada Mata Kuliah';
                $tanggal = $row['tanggal'] ?? 'Tidak Ada Tanggal';
                $kehadiran = $row['kehadiran'] ?? 'Tidak Ada Kehadiran';
                $lokasi = $row['lokasi'] ?? 'Tidak Ada Lokasi';
                $qrcode = $row['qrcode'] ?? 'Tidak Ada QR Code';

                $mapLink = $lokasi ? "https://www.google.com/maps?q=" . urlencode($lokasi) : '#';
                $qrLink = $qrcode ? "../assets/qrcodes/$qrcode" : '#';

                echo "<tr>
                    <td>$nama</td>
                    <td>$identifier</td>
                    <td>$mata_kuliah</td>
                    <td>$tanggal</td>
                    <td>$kehadiran</td>
                    <td><a href='$mapLink' target='_blank'>Lihat Lokasi</a></td>
                    <td><a href='$qrLink' download>Download QR Code</a></td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='7'>Tidak ada data absensi</td></tr>";
        }
        ?>
    </tbody>
</table>

