<?php
include '../backend/maps/maps_handler.php';

// Koordinat lokasi
$latitude = -6.2088; // Contoh: Jakarta
$longitude = 106.8456;
$apiKey = "YOUR_GOOGLE_MAPS_API_KEY"; // Ganti dengan API Key Anda
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maps - Lokasi</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="maps-container">
        <h2>Lokasi Perkuliahan</h2>
        <div class="map-frame">
            <?= embedGoogleMaps($latitude, $longitude, $apiKey); ?>
        </div>
    </div>
</body>
</html>
