<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Superuser</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <h2>Dashboard Superuser</h2>
        <a href="../backend/auth/logout.php">Logout</a>
        <table border="1" cellpadding="10" cellspacing="0">
            <thead>
                <tr>
                    <th>Nama Lengkap</th>
                    <th>Identifier</th>
                    <th>Mata Kuliah</th>
                    <th>Pertemuan</th>
                    <th>Kehadiran</th>
                    <th>QR Code</th>
                </tr>
            </thead>
            <tbody id="absensi-data">
                <!-- Data akan dimuat dengan JavaScript -->
            </tbody>
        </table>
    </div>
    <script src="../assets/js/script.js"></script>
    <script>
        fetch('../backend/superuser/dashboard.php')
            .then(response => response.json())
            .then(data => {
                const tbody = document.getElementById('absensi-data');
                data.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.nama_lengkap}</td>
                        <td>${item.identifier}</td>
                        <td>${item.mata_kuliah}</td>
                        <td>${item.pertemuan}</td>
                        <td>${item.kehadiran}</td>
                        <td><img src="../assets/qrcodes/${item.qrcode}" alt="QR Code" width="50"></td>
                    `;
                    tbody.appendChild(row);
                });
            });
    </script>
</body>
</html>
