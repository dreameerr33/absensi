document.addEventListener("DOMContentLoaded", () => {
    console.log("Script loaded successfully.");
});
