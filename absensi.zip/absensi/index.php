<?php
header("Location: frontend/login.php");
exit();
?>
