<?php
session_start();
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $_SESSION['user'] = $user;

        // Redirect based on role
        if ($user['role'] === 'admin') {
            header("Location: ../../frontend/admin_dashboard.php");
        } elseif ($user['role'] === 'superuser') {
            header("Location: ../../frontend/superuser_dashboard.php");
        } elseif ($user['role'] === 'mahasiswa') {
            header("Location: ../../frontend/mahasiswa_absen.php");
        }
    } else {
        echo "<script>alert('Login failed. Check your username and password.'); window.location.href='../../frontend/login.php';</script>";
    }
}
?>

