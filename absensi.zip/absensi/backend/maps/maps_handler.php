<?php
function generateGoogleMapsLink($latitude, $longitude) {
    return "https://www.google.com/maps?q={$latitude},{$longitude}";
}

function embedGoogleMaps($latitude, $longitude, $apiKey) {
    return "<iframe
        width='600'
        height='450'
        style='border:0'
        loading='lazy'
        allowfullscreen
        referrerpolicy='no-referrer-when-downgrade'
        src='https://www.google.com/maps/embed/v1/place?key={$apiKey}&q={$latitude},{$longitude}'>
    </iframe>";
}
?>
