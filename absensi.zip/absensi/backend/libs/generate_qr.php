<?php
include 'qrlib.php';

function generateQRCode($data) {
    $filePath = '../../assets/qrcodes/' . uniqid() . '.png';
    QRcode::png($data, $filePath, QR_ECLEVEL_L, 10);
    return $filePath;
}
?>
