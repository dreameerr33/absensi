<?php
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama_lengkap'];
    $nim = $_POST['identifier'];
    $kehadiran = $_POST['kehadiran'];
    $tanggal = $_POST['tanggal'];
    $mata_kuliah = $_POST['mata_kuliah'];
    $lokasi = $_POST['lokasi']; // Data lokasi
    $pertemuan = 1; // Otomatis diatur, bisa dikembangkan lebih lanjut.

    // Generate QR Code
    include '../libs/generate_qr.php';
    $qrcode_path = generateQRCode("Nama: $nama, NIM: $nim, Lokasi: $lokasi, Tanggal: $tanggal");

    $query = "INSERT INTO absensi (nama_lengkap, identifier, kehadiran, hari, tanggal, mata_kuliah, pertemuan, lokasi, qrcode)
              VALUES (?, ?, ?, DAYNAME(?), ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssssssiss', $nama, $nim, $kehadiran, $tanggal, $tanggal, $mata_kuliah, $pertemuan, $lokasi, $qrcode_path);

    if ($stmt->execute()) {
        echo "Absensi berhasil disimpan!";
    } else {
        echo "Gagal menyimpan absensi!";
    }
}
?>
