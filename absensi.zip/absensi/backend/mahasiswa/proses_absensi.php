<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "absensi";

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form
$nama = isset($_POST['nama_lengkap']) ? $_POST['nama_lengkap'] : null;
$nim = isset($_POST['identifier']) ? $_POST['identifier'] : null;
$kehadiran = isset($_POST['kehadiran']) ? $_POST['kehadiran'] : null;
$tanggal = isset($_POST['tanggal']) ? $_POST['tanggal'] : null;
$mata_kuliah = isset($_POST['mata_kuliah']) ? $_POST['mata_kuliah'] : null;
$lokasi = isset($_POST['lokasi']) ? $_POST['lokasi'] : null;
$qrcode = isset($_POST['qrcode']) ? $_POST['qrcode'] : null;

// Validasi input
if (empty($nama) || empty($nim) || empty($kehadiran) || empty($tanggal) || empty($mata_kuliah) || empty($lokasi) || empty($qrcode)) {
    die("Error: Semua field harus diisi.");
}

// Gunakan prepared statement untuk menyimpan data
$sql = $conn->prepare("INSERT INTO absensi (nama_lengkap, nim, kehadiran, tanggal, mata_kuliah, lokasi, qr_code) 
                       VALUES (?, ?, ?, ?, ?, ?, ?)");
if (!$sql) {
    die("Error dalam persiapan query: " . $conn->error);
}

// Bind parameter
$sql->bind_param("sssssss", $nama, $nim, $kehadiran, $tanggal, $mata_kuliah, $lokasi, $qrcode);

// Eksekusi query
if ($sql->execute()) {
    echo "Data berhasil disimpan.";
} else {
    echo "Error: " . $sql->error;
}

// Tutup koneksi
$sql->close();
$conn->close();
?>
