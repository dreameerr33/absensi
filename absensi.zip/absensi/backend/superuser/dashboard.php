<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'superuser') {
    header('Location: ../../frontend/login.php');
    exit();
}

$query = "SELECT * FROM absensi";
$result = $conn->query($query);

$absensi = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $absensi[] = $row;
    }
}

echo json_encode($absensi);
?>
