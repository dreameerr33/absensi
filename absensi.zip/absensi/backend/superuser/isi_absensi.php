<?php
session_start();
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_lengkap = $_POST['nama_lengkap'];
    $identifier = $_POST['identifier'];
    $kehadiran = $_POST['kehadiran'];
    $hari = $_POST['hari'];
    $tanggal = $_POST['tanggal'];
    $mata_kuliah = $_POST['mata_kuliah'];
    $pertemuan = $_POST['pertemuan'];

    $qrcode_data = "{$nama_lengkap}-{$identifier}-{$mata_kuliah}-Pertemuan{$pertemuan}";
    include '../libs/generate_qr.php';
    $qrcode = generateQRCode($qrcode_data);

    $query = "INSERT INTO absensi (nama_lengkap, identifier, kehadiran, hari, tanggal, mata_kuliah, pertemuan, qrcode) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssssis", $nama_lengkap, $identifier, $kehadiran, $hari, $tanggal, $mata_kuliah, $pertemuan, $qrcode);
    $stmt->execute();
    header('Location: ../../frontend/superuser_dashboard.php');
}
?>
